// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'form_stats_state.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_FormStatsState _$$_FormStatsStateFromJson(Map<String, dynamic> json) =>
    _$_FormStatsState(
      textGridSize: json['textGridSize'] as int?,
    );

Map<String, dynamic> _$$_FormStatsStateToJson(_$_FormStatsState instance) =>
    <String, dynamic>{
      'textGridSize': instance.textGridSize,
    };
