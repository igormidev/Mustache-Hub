import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:micromustachehub/src/generate/interactor/entities/dtos/generator_data_dto.dart';

part 'payload_state.freezed.dart';

@freezed
abstract class PayloadState with _$PayloadState {
  /// Whe the user did not putted all required fields
  factory PayloadState.withPendencies({
    required bool allRequiredFieldsComplete,
    required bool haveVariables,
    required bool haveContent,
    required GeneratorDataDto? data,
  }) = _NeedToPutRequiredFields;

  factory PayloadState.withObjects({
    required GeneratorDataDto data,
  }) = PayloadStateWithData;

  factory PayloadState.failureGeneratingText({
    required GeneratorDataDto data,
  }) = FailureGeneratingText;
}

extension PayloadStateExtension on PayloadState {
  GeneratorDataDto? get generatorData => map(
        withPendencies: (value) => value.data,
        withObjects: (value) => value.data,
        failureGeneratingText: (value) => value.data,
      );
}

enum PayloadPendingDependency {
  requiredFields,
  emptyContentText;
}
