// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'payload_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$PayloadState {
  GeneratorDataDto? get data => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool allRequiredFieldsComplete,
            bool haveVariables, bool haveContent, GeneratorDataDto? data)
        withPendencies,
    required TResult Function(GeneratorDataDto data) withObjects,
    required TResult Function(GeneratorDataDto data) failureGeneratingText,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool allRequiredFieldsComplete, bool haveVariables,
            bool haveContent, GeneratorDataDto? data)?
        withPendencies,
    TResult? Function(GeneratorDataDto data)? withObjects,
    TResult? Function(GeneratorDataDto data)? failureGeneratingText,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool allRequiredFieldsComplete, bool haveVariables,
            bool haveContent, GeneratorDataDto? data)?
        withPendencies,
    TResult Function(GeneratorDataDto data)? withObjects,
    TResult Function(GeneratorDataDto data)? failureGeneratingText,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_NeedToPutRequiredFields value) withPendencies,
    required TResult Function(PayloadStateWithData value) withObjects,
    required TResult Function(FailureGeneratingText value)
        failureGeneratingText,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_NeedToPutRequiredFields value)? withPendencies,
    TResult? Function(PayloadStateWithData value)? withObjects,
    TResult? Function(FailureGeneratingText value)? failureGeneratingText,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_NeedToPutRequiredFields value)? withPendencies,
    TResult Function(PayloadStateWithData value)? withObjects,
    TResult Function(FailureGeneratingText value)? failureGeneratingText,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $PayloadStateCopyWith<PayloadState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PayloadStateCopyWith<$Res> {
  factory $PayloadStateCopyWith(
          PayloadState value, $Res Function(PayloadState) then) =
      _$PayloadStateCopyWithImpl<$Res, PayloadState>;
  @useResult
  $Res call({GeneratorDataDto data});
}

/// @nodoc
class _$PayloadStateCopyWithImpl<$Res, $Val extends PayloadState>
    implements $PayloadStateCopyWith<$Res> {
  _$PayloadStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = null,
  }) {
    return _then(_value.copyWith(
      data: null == data
          ? _value.data!
          : data // ignore: cast_nullable_to_non_nullable
              as GeneratorDataDto,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_NeedToPutRequiredFieldsCopyWith<$Res>
    implements $PayloadStateCopyWith<$Res> {
  factory _$$_NeedToPutRequiredFieldsCopyWith(_$_NeedToPutRequiredFields value,
          $Res Function(_$_NeedToPutRequiredFields) then) =
      __$$_NeedToPutRequiredFieldsCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool allRequiredFieldsComplete,
      bool haveVariables,
      bool haveContent,
      GeneratorDataDto? data});
}

/// @nodoc
class __$$_NeedToPutRequiredFieldsCopyWithImpl<$Res>
    extends _$PayloadStateCopyWithImpl<$Res, _$_NeedToPutRequiredFields>
    implements _$$_NeedToPutRequiredFieldsCopyWith<$Res> {
  __$$_NeedToPutRequiredFieldsCopyWithImpl(_$_NeedToPutRequiredFields _value,
      $Res Function(_$_NeedToPutRequiredFields) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? allRequiredFieldsComplete = null,
    Object? haveVariables = null,
    Object? haveContent = null,
    Object? data = freezed,
  }) {
    return _then(_$_NeedToPutRequiredFields(
      allRequiredFieldsComplete: null == allRequiredFieldsComplete
          ? _value.allRequiredFieldsComplete
          : allRequiredFieldsComplete // ignore: cast_nullable_to_non_nullable
              as bool,
      haveVariables: null == haveVariables
          ? _value.haveVariables
          : haveVariables // ignore: cast_nullable_to_non_nullable
              as bool,
      haveContent: null == haveContent
          ? _value.haveContent
          : haveContent // ignore: cast_nullable_to_non_nullable
              as bool,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as GeneratorDataDto?,
    ));
  }
}

/// @nodoc

class _$_NeedToPutRequiredFields implements _NeedToPutRequiredFields {
  _$_NeedToPutRequiredFields(
      {required this.allRequiredFieldsComplete,
      required this.haveVariables,
      required this.haveContent,
      required this.data});

  @override
  final bool allRequiredFieldsComplete;
  @override
  final bool haveVariables;
  @override
  final bool haveContent;
  @override
  final GeneratorDataDto? data;

  @override
  String toString() {
    return 'PayloadState.withPendencies(allRequiredFieldsComplete: $allRequiredFieldsComplete, haveVariables: $haveVariables, haveContent: $haveContent, data: $data)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_NeedToPutRequiredFields &&
            (identical(other.allRequiredFieldsComplete,
                    allRequiredFieldsComplete) ||
                other.allRequiredFieldsComplete == allRequiredFieldsComplete) &&
            (identical(other.haveVariables, haveVariables) ||
                other.haveVariables == haveVariables) &&
            (identical(other.haveContent, haveContent) ||
                other.haveContent == haveContent) &&
            (identical(other.data, data) || other.data == data));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, allRequiredFieldsComplete, haveVariables, haveContent, data);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_NeedToPutRequiredFieldsCopyWith<_$_NeedToPutRequiredFields>
      get copyWith =>
          __$$_NeedToPutRequiredFieldsCopyWithImpl<_$_NeedToPutRequiredFields>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool allRequiredFieldsComplete,
            bool haveVariables, bool haveContent, GeneratorDataDto? data)
        withPendencies,
    required TResult Function(GeneratorDataDto data) withObjects,
    required TResult Function(GeneratorDataDto data) failureGeneratingText,
  }) {
    return withPendencies(
        allRequiredFieldsComplete, haveVariables, haveContent, data);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool allRequiredFieldsComplete, bool haveVariables,
            bool haveContent, GeneratorDataDto? data)?
        withPendencies,
    TResult? Function(GeneratorDataDto data)? withObjects,
    TResult? Function(GeneratorDataDto data)? failureGeneratingText,
  }) {
    return withPendencies?.call(
        allRequiredFieldsComplete, haveVariables, haveContent, data);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool allRequiredFieldsComplete, bool haveVariables,
            bool haveContent, GeneratorDataDto? data)?
        withPendencies,
    TResult Function(GeneratorDataDto data)? withObjects,
    TResult Function(GeneratorDataDto data)? failureGeneratingText,
    required TResult orElse(),
  }) {
    if (withPendencies != null) {
      return withPendencies(
          allRequiredFieldsComplete, haveVariables, haveContent, data);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_NeedToPutRequiredFields value) withPendencies,
    required TResult Function(PayloadStateWithData value) withObjects,
    required TResult Function(FailureGeneratingText value)
        failureGeneratingText,
  }) {
    return withPendencies(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_NeedToPutRequiredFields value)? withPendencies,
    TResult? Function(PayloadStateWithData value)? withObjects,
    TResult? Function(FailureGeneratingText value)? failureGeneratingText,
  }) {
    return withPendencies?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_NeedToPutRequiredFields value)? withPendencies,
    TResult Function(PayloadStateWithData value)? withObjects,
    TResult Function(FailureGeneratingText value)? failureGeneratingText,
    required TResult orElse(),
  }) {
    if (withPendencies != null) {
      return withPendencies(this);
    }
    return orElse();
  }
}

abstract class _NeedToPutRequiredFields implements PayloadState {
  factory _NeedToPutRequiredFields(
      {required final bool allRequiredFieldsComplete,
      required final bool haveVariables,
      required final bool haveContent,
      required final GeneratorDataDto? data}) = _$_NeedToPutRequiredFields;

  bool get allRequiredFieldsComplete;
  bool get haveVariables;
  bool get haveContent;
  @override
  GeneratorDataDto? get data;
  @override
  @JsonKey(ignore: true)
  _$$_NeedToPutRequiredFieldsCopyWith<_$_NeedToPutRequiredFields>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$PayloadStateWithDataCopyWith<$Res>
    implements $PayloadStateCopyWith<$Res> {
  factory _$$PayloadStateWithDataCopyWith(_$PayloadStateWithData value,
          $Res Function(_$PayloadStateWithData) then) =
      __$$PayloadStateWithDataCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({GeneratorDataDto data});
}

/// @nodoc
class __$$PayloadStateWithDataCopyWithImpl<$Res>
    extends _$PayloadStateCopyWithImpl<$Res, _$PayloadStateWithData>
    implements _$$PayloadStateWithDataCopyWith<$Res> {
  __$$PayloadStateWithDataCopyWithImpl(_$PayloadStateWithData _value,
      $Res Function(_$PayloadStateWithData) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = null,
  }) {
    return _then(_$PayloadStateWithData(
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as GeneratorDataDto,
    ));
  }
}

/// @nodoc

class _$PayloadStateWithData implements PayloadStateWithData {
  _$PayloadStateWithData({required this.data});

  @override
  final GeneratorDataDto data;

  @override
  String toString() {
    return 'PayloadState.withObjects(data: $data)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PayloadStateWithData &&
            (identical(other.data, data) || other.data == data));
  }

  @override
  int get hashCode => Object.hash(runtimeType, data);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PayloadStateWithDataCopyWith<_$PayloadStateWithData> get copyWith =>
      __$$PayloadStateWithDataCopyWithImpl<_$PayloadStateWithData>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool allRequiredFieldsComplete,
            bool haveVariables, bool haveContent, GeneratorDataDto? data)
        withPendencies,
    required TResult Function(GeneratorDataDto data) withObjects,
    required TResult Function(GeneratorDataDto data) failureGeneratingText,
  }) {
    return withObjects(data);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool allRequiredFieldsComplete, bool haveVariables,
            bool haveContent, GeneratorDataDto? data)?
        withPendencies,
    TResult? Function(GeneratorDataDto data)? withObjects,
    TResult? Function(GeneratorDataDto data)? failureGeneratingText,
  }) {
    return withObjects?.call(data);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool allRequiredFieldsComplete, bool haveVariables,
            bool haveContent, GeneratorDataDto? data)?
        withPendencies,
    TResult Function(GeneratorDataDto data)? withObjects,
    TResult Function(GeneratorDataDto data)? failureGeneratingText,
    required TResult orElse(),
  }) {
    if (withObjects != null) {
      return withObjects(data);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_NeedToPutRequiredFields value) withPendencies,
    required TResult Function(PayloadStateWithData value) withObjects,
    required TResult Function(FailureGeneratingText value)
        failureGeneratingText,
  }) {
    return withObjects(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_NeedToPutRequiredFields value)? withPendencies,
    TResult? Function(PayloadStateWithData value)? withObjects,
    TResult? Function(FailureGeneratingText value)? failureGeneratingText,
  }) {
    return withObjects?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_NeedToPutRequiredFields value)? withPendencies,
    TResult Function(PayloadStateWithData value)? withObjects,
    TResult Function(FailureGeneratingText value)? failureGeneratingText,
    required TResult orElse(),
  }) {
    if (withObjects != null) {
      return withObjects(this);
    }
    return orElse();
  }
}

abstract class PayloadStateWithData implements PayloadState {
  factory PayloadStateWithData({required final GeneratorDataDto data}) =
      _$PayloadStateWithData;

  @override
  GeneratorDataDto get data;
  @override
  @JsonKey(ignore: true)
  _$$PayloadStateWithDataCopyWith<_$PayloadStateWithData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$FailureGeneratingTextCopyWith<$Res>
    implements $PayloadStateCopyWith<$Res> {
  factory _$$FailureGeneratingTextCopyWith(_$FailureGeneratingText value,
          $Res Function(_$FailureGeneratingText) then) =
      __$$FailureGeneratingTextCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({GeneratorDataDto data});
}

/// @nodoc
class __$$FailureGeneratingTextCopyWithImpl<$Res>
    extends _$PayloadStateCopyWithImpl<$Res, _$FailureGeneratingText>
    implements _$$FailureGeneratingTextCopyWith<$Res> {
  __$$FailureGeneratingTextCopyWithImpl(_$FailureGeneratingText _value,
      $Res Function(_$FailureGeneratingText) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = null,
  }) {
    return _then(_$FailureGeneratingText(
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as GeneratorDataDto,
    ));
  }
}

/// @nodoc

class _$FailureGeneratingText implements FailureGeneratingText {
  _$FailureGeneratingText({required this.data});

  @override
  final GeneratorDataDto data;

  @override
  String toString() {
    return 'PayloadState.failureGeneratingText(data: $data)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FailureGeneratingText &&
            (identical(other.data, data) || other.data == data));
  }

  @override
  int get hashCode => Object.hash(runtimeType, data);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FailureGeneratingTextCopyWith<_$FailureGeneratingText> get copyWith =>
      __$$FailureGeneratingTextCopyWithImpl<_$FailureGeneratingText>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool allRequiredFieldsComplete,
            bool haveVariables, bool haveContent, GeneratorDataDto? data)
        withPendencies,
    required TResult Function(GeneratorDataDto data) withObjects,
    required TResult Function(GeneratorDataDto data) failureGeneratingText,
  }) {
    return failureGeneratingText(data);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool allRequiredFieldsComplete, bool haveVariables,
            bool haveContent, GeneratorDataDto? data)?
        withPendencies,
    TResult? Function(GeneratorDataDto data)? withObjects,
    TResult? Function(GeneratorDataDto data)? failureGeneratingText,
  }) {
    return failureGeneratingText?.call(data);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool allRequiredFieldsComplete, bool haveVariables,
            bool haveContent, GeneratorDataDto? data)?
        withPendencies,
    TResult Function(GeneratorDataDto data)? withObjects,
    TResult Function(GeneratorDataDto data)? failureGeneratingText,
    required TResult orElse(),
  }) {
    if (failureGeneratingText != null) {
      return failureGeneratingText(data);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_NeedToPutRequiredFields value) withPendencies,
    required TResult Function(PayloadStateWithData value) withObjects,
    required TResult Function(FailureGeneratingText value)
        failureGeneratingText,
  }) {
    return failureGeneratingText(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_NeedToPutRequiredFields value)? withPendencies,
    TResult? Function(PayloadStateWithData value)? withObjects,
    TResult? Function(FailureGeneratingText value)? failureGeneratingText,
  }) {
    return failureGeneratingText?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_NeedToPutRequiredFields value)? withPendencies,
    TResult Function(PayloadStateWithData value)? withObjects,
    TResult Function(FailureGeneratingText value)? failureGeneratingText,
    required TResult orElse(),
  }) {
    if (failureGeneratingText != null) {
      return failureGeneratingText(this);
    }
    return orElse();
  }
}

abstract class FailureGeneratingText implements PayloadState {
  factory FailureGeneratingText({required final GeneratorDataDto data}) =
      _$FailureGeneratingText;

  @override
  GeneratorDataDto get data;
  @override
  @JsonKey(ignore: true)
  _$$FailureGeneratingTextCopyWith<_$FailureGeneratingText> get copyWith =>
      throw _privateConstructorUsedError;
}
