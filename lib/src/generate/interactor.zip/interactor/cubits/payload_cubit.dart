import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:micromustachehub/src/generate/interactor/adapters/dto_adapter.dart';
import 'package:micromustachehub/src/generate/interactor/entities/dtos/generator_data_dto.dart';
import 'package:micromustachehub/src/generate/interactor/entities/dtos/pipe_dto.dart';
import 'package:micromustachehub/src/generate/interactor/entities/template/generator_data.dart';
import 'package:micromustachehub/src/generate/interactor/entities/template/pipe.dart';
import 'package:micromustachehub/src/generate/interactor/mixins/mustache_text_mixin.dart';
import 'package:micromustachehub/src/generate/interactor/states/payload_state.dart';

class PayloadCubit extends Cubit<PayloadState> with MustacheTextMixin {
  final DtoAdapter _dtoAdapter;
  PayloadCubit({
    required DtoAdapter dtoAdapter,
  })  : _dtoAdapter = dtoAdapter,
        super(PayloadState.withPendencies(
          haveContent: false,
          allRequiredFieldsComplete: false,
          haveVariables: false,
          data: null,
        ));

  Future<void> _addData({
    required GeneratorData generatorData,
  }) async {
    final areAllVariablesEmpty = generatorData.textPipes.isEmpty &&
        generatorData.booleanPipes.isEmpty &&
        generatorData.modelPipes.isEmpty;

    final hasContent = generatorData.content.isNotEmpty;

    if (hasContent == false || areAllVariablesEmpty) {
      // Both false
      if (hasContent == false && areAllVariablesEmpty) {
        return emit(PayloadState.withPendencies(
          haveContent: false,
          haveVariables: false,
          allRequiredFieldsComplete: false,
          data: null,
        ));
      }

      if (areAllVariablesEmpty) {
        return emit(PayloadState.withPendencies(
          haveContent: true,
          allRequiredFieldsComplete: false,
          haveVariables: false,
          data: GeneratorDataDto(
            generatedText: generatorData.content,
            textDtos: const [],
            booleanDtos: const [],
          ),
        ));
      }

      return;
    }

    final GeneratorDataDto? prevDataDto = state.generatorData;

    // TODO(igor): Add isolate here
    final updatedPipeDtos = _dtoAdapter.dtosFromTemplate(
      generatorData,
      prevDataDto?.textDtos,
      prevDataDto?.booleanDtos,
    );

    await generateContent(
      generatorData: generatorData,
      dataDto: GeneratorDataDto(
        generatedText: null,
        textDtos: updatedPipeDtos.textPipes,
        booleanDtos: updatedPipeDtos.boolPipes,
      ),
    );
  }

  Future<void> generateContent({
    required GeneratorData generatorData,
    required GeneratorDataDto? dataDto,
  }) async {
    if (dataDto == null) {
      await _addData(generatorData: generatorData);
      return;
    }

    // TODO(igor): Put in a isolate
    final Map<String, dynamic> payload = _dtoAdapter.getPayloadFromDtos(
      texts: generatorData.textPipes,
      booleans: generatorData.booleanPipes,
      models: generatorData.modelPipes,
      textDtos: dataDto.textDtos,
      booleanDtos: dataDto.booleanDtos,
    );

    final hasContent = generatorData.content.isNotEmpty;
    if (hasContent == false) {
      emit(PayloadState.withPendencies(
        haveContent: true,
        allRequiredFieldsComplete: true,
        haveVariables: true,
        data: dataDto,
      ));
    }

    final output = getMustacheText(generatorData.content, payload);
    if (output == null) {
      // Error happend, null output
      emit(PayloadState.failureGeneratingText(
        data: dataDto.copyWith(generatedText: null),
      ));
    } else {
      emit(PayloadState.withObjects(
        data: dataDto.copyWith(generatedText: output),
      ));
    }
  }

  void setStateToPendingRequiredFields(
    bool haveContent,
  ) {
    return;
    final data = state.generatorData;
    if (data == null) return;

    emit(
      PayloadState.withPendencies(
        allRequiredFieldsComplete: false,
        haveContent: haveContent,
        haveVariables: true,
        data: data,
      ),
    );
  }

  Future<void> addTextPayloadValue({
    required GeneratorData generatorData,
    required TextPipe pipe,
    required String? value,
  }) async {
    final GeneratorDataDto? dataDto = state.generatorData;

    if (dataDto == null) return;

    final List<TextPipeDto> newDtos = [...dataDto.textDtos];
    final index = newDtos.indexWhere((dto) => dto.pipe.pipeId == pipe.pipeId);
    newDtos[index] = newDtos[index].copyWith(payloadValue: value);

    await generateContent(
      generatorData: generatorData,
      dataDto: dataDto.copyWith(
        textDtos: newDtos,
      ),
    );
  }

  Future<void> addBooleanPayloadValue({
    required GeneratorData generatorData,
    required BooleanPipe pipe,
    required bool value,
  }) async {
    final GeneratorDataDto? dataDto = state.generatorData;

    if (dataDto == null) return;

    final List<BooleanPipeDto> newDtos = [...dataDto.booleanDtos];
    final index = newDtos.indexWhere((dto) => dto.pipe.pipeId == pipe.pipeId);
    newDtos[index] = newDtos[index].copyWith(payloadValue: value);

    await generateContent(
      generatorData: generatorData,
      dataDto: dataDto.copyWith(
        booleanDtos: newDtos,
      ),
    );
  }
}
